/* ---------------------------------------------------------------------- */
/* Filename    : cre_cd_collections_tables.sql                            */
/* Project name: 10 Data Models for SQL Server 2005 Express Edition       */
/* Author      : Barry Williams                                           */
/* Created at  : 10.00 am on Saturday, 26th. August 2006                  */
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */
/* Create Tables and Views                                                */
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */
/* Add table "Ref_CD_Outlet"                                              */
/* eg CD Now, Tower Records, etc..                                        */
/* ---------------------------------------------------------------------- */

CREATE TABLE Ref_CD_Outlets (
    [outlet_code] CHAR(15) NOT NULL PRIMARY KEY,
    [outlet_description] VARCHAR(80)
)
GO

INSERT INTO Ref_CD_Outlets (outlet_code, outlet_description)
VALUES                     ('Amazon', 'Online Music Division')
GO

INSERT INTO Ref_CD_Outlets (outlet_code, outlet_description)
VALUES                     ('CD Now', 'Online Music Store')
GO

INSERT INTO Ref_CD_Outlets (outlet_code, outlet_description)
VALUES                     ('Tower', 'Tower Records - Chain of Global Record Stores')
GO

SELECT * FROM Ref_CD_Outlets
ORDER  BY outlet_code
GO


/* ---------------------------------------------------------------------- */
/* Add table "Ref_Music_Genres"                                           */
/* ---------------------------------------------------------------------- */


CREATE TABLE [Ref_Music_Genres] (
    [music_genre_code] CHAR(15) NOT NULL PRIMARY KEY,
    [music_genre_description] VARCHAR(80)
)
GO

/* ---------------------------------------------------------------------- */
/* Load Data into table "Ref_Music_Genres"                                           */
/* ---------------------------------------------------------------------- */

INSERT INTO Ref_Music_Genres (music_genre_code,music_genre_description) 
VALUES                       ('Country','Country and Western, eg Willy Nelson')
GO

INSERT INTO Ref_Music_Genres (music_genre_code,music_genre_description) 
VALUES                       ('Easy','Easy Listening, eg Richard Clayderman')
GO

INSERT INTO Ref_Music_Genres (music_genre_code,music_genre_description) 
VALUES                       ('Funk','eg James Brown')
GO

INSERT INTO Ref_Music_Genres (music_genre_code,music_genre_description)
VALUES                       ('Jazz','eg Norah Jones')
GO

INSERT INTO Ref_Music_Genres (music_genre_code,music_genre_description)
VALUES                       ('Soul','eg Aretha')
GO

SELECT * FROM Ref_Music_Genres;
GO

/* ---------------------------------------------------------------------- */
/* Add table "Record Companies"                                           */
/* ---------------------------------------------------------------------- */

CREATE TABLE Record_Companies (
    rcd_company_code CHAR(15) NOT NULL PRIMARY KEY,
    rcd_company_name CHAR(80)     NULL,
    rcd_company_details CHAR(255) NULL
)
GO

INSERT INTO Record_Companies
(rcd_company_code, rcd_company_name,rcd_company_details)
VALUES ('Malaco','The Malaco Music Group','Based in Jackson, Missippi')
GO

SELECT * FROM Record_Companies
GO

/* ---------------------------------------------------------------------- */
/* Add table "Artists"                                                    */
/* ---------------------------------------------------------------------- */

CREATE TABLE Artists (
    [artist_name] VARCHAR(80) NOT NULL PRIMARY KEY,
    [date_of_birth] DATETIME,
    [gender] CHAR(1),
    [height] CHAR(8),
    [weight] CHAR(8),
    [photo_filename] VARCHAR(255),
    [other_artist_details] VARCHAR(255)
)
GO

INSERT INTO Artists (artist_name,gender)
VALUES              ('Aretha Franklin','F')
GO

INSERT INTO Artists (artist_name,gender)
VALUES              ('James Brown','M')
GO

INSERT INTO Artists (artist_name,gender)
VALUES              ('Norah Jones','F')
GO

INSERT INTO Artists (artist_name,gender)
VALUES              ('Ray Charles','M')
GO

INSERT INTO Artists (artist_name,gender)
VALUES              ('Various','U')
GO

INSERT INTO Artists (artist_name,gender)
VALUES              ('Willy Nelson','M')
GO

SELECT artist_name,gender
FROM   Artists
GO


/* ---------------------------------------------------------------------- */
/* Add table "CD_Sets"                                                    */
/* ---------------------------------------------------------------------- */

CREATE TABLE CD_Sets (
    cd_set_id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT newid(),
    rcd_company_code 	CHAR(15),
    total_number_in_set INTEGER,
    cd_set_name 	varchar(80),
FOREIGN KEY (rcd_company_code) REFERENCES Record_Companies (rcd_company_code)
)
GO

INSERT INTO CD_Sets  (rcd_company_code,total_number_in_set, cd_set_name)
VALUES               ('Malaco',6,'The Last Soul Company')
GO

SELECT * FROM CD_Sets
GO


/* ---------------------------------------------------------------------- */
/* Add table "CDs"                                                        */
/* ---------------------------------------------------------------------- */

CREATE TABLE CDs (
    [cd_id] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT newid(),
    [music_genre_code] CHAR(15),
    [outlet_code] CHAR(15),
    rcd_company_code 	CHAR(15),
    cd_set_id UNIQUEIDENTIFIER,
    seq_number_in_set INTEGER,
    cd_title varchar(80),
    [various_artists_yn] CHAR(1),
    artist_name varchar(80),
    [cost] MONEY,
    [date_released] DATETIME,
    [date_acquired] DATETIME,
    [number_of_tracks] INTEGER,
    [total_playing_time] CHAR(15),
FOREIGN KEY (artist_name)      REFERENCES Artists          (artist_name),
FOREIGN KEY (music_genre_code) REFERENCES Ref_Music_Genres (music_genre_code),
FOREIGN KEY (outlet_code)      REFERENCES Ref_CD_Outlets   (outlet_code)
)
GO

/*
INSERT INTO CDs 
(cd_set_id,artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
SELECT cd_set_id,'Various','Disk One - The Last Soul Company','Soul','Amazon','01/jan/1961','01/mar/2000',12,'70 mins','Y'
FROM   CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
GO
*/

INSERT INTO CDs 
(cd_set_id,seq_number_in_set,artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
SELECT cd_set_id,1, 'Various','Disk One - The Last Soul Company','Soul','Amazon','01/jan/1961','01/mar/2000',12,'70 mins','Y'
FROM   CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
GO

INSERT INTO CDs 
(cd_set_id,seq_number_in_set,artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
SELECT cd_set_id,2,'Various','Disk Two - The Last Soul Company','Soul','Amazon','01/jan/1961','01/mar/2000',12,'70 mins','Y'
FROM   CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
GO

INSERT INTO CDs 
(cd_set_id,seq_number_in_set,artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
SELECT cd_set_id,3,'Various','Disk Three - The Last Soul Company','Soul','Amazon','01/jan/1961','01/mar/2000',12,'70 mins','Y'
FROM   CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
GO

INSERT INTO CDs 
(cd_set_id,seq_number_in_set,artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
SELECT cd_set_id,4,'Various','Disk Four - The Last Soul Company','Soul','Amazon','01/jan/1961','01/mar/2000',12,'70 mins','Y'
FROM   CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
GO

INSERT INTO CDs 
(cd_set_id,seq_number_in_set,artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
SELECT cd_set_id,5,'Various','Disk Five - The Last Soul Company','Soul','Amazon','01/jan/1961','01/mar/2000',12,'70 mins','Y'
FROM   CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
GO

INSERT INTO CDs 
(cd_set_id,seq_number_in_set,artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
SELECT cd_set_id,6,'Various','Disk Six - The Last Soul Company','Soul','Amazon','01/jan/1961','01/mar/2000',12,'70 mins','Y'
FROM   CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
GO



SELECT 'CD_Sets' AS Table_name,rcd_company_code,total_number_in_set, cd_set_name 
FROM	CD_Sets;
GO

INSERT INTO CDs 
(artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
VALUES ('James Brown','Live at the Appollo','Funk','CD Now','01/jan/1961','01/mar/2000',12,'70 mins','N')
GO

INSERT INTO CDs 
(artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
VALUES ('Norah Jones','come away with me','Jazz','CD Now','01/jan/2004','01/mar/2006',11,'80 mins','N')
GO

INSERT INTO CDs 
(artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
VALUES ('Ray Charles','The Right Time','Soul','CD Now','01/jan/1997','01/mar/2005',20,'90 mins','N')
GO

/*
INSERT INTO CDs 
(artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
VALUES ('Various','The Last Soul Company','Soul','Tower','01/jan/1987','02/dec/2000',65,'200 mins','Y')
GO
*/

INSERT INTO CDs 
(artist_name,cd_title,music_genre_code, outlet_code,date_released,date_acquired,number_of_tracks,total_playing_time,various_artists_yn)
VALUES ('Willy Nelson','A Country Hobo','Country','CD Now','01/jan/1991','01/mar/2000',12,'70 mins','N')
GO

SELECT artist_name,cd_title,outlet_code,various_artists_yn
FROM   CDs
ORDER BY artist_name,cd_title;
GO

/* BARRY - 10.30 pm Friday, 25th. August 2006 */


/* ---------------------------------------------------------------------- */
/* Add table "CD_Tracks"                                                  */
/* ---------------------------------------------------------------------- */

CREATE TABLE CD_Tracks (
    [cd_id] UNIQUEIDENTIFIER,
    [track_number] INTEGER,
    artist_name varchar(80),
    [track_length] VARCHAR(10),
    [track_title] VARCHAR(80),
    [comment] VARCHAR(255),
PRIMARY KEY (cd_id,track_number),
FOREIGN KEY (cd_id) REFERENCES CDs (cd_id)
)
GO

/* BARRY - 12.30 pm Saturday, 26th. August 2006 */


INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,1,'Haran Griffin','Looking for my Pig'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk One - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,2,'Cozey Corley','Warm Loving Man'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk One - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,3,'Eddie Houston','I Can"t Go Wrong'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk One - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,4,'Jackie Dorsey','Sweetheart Baby'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk One - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,1,'King Floyd, Dorothy Moore,','We Can Love'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk Two - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,2,'Dorothy Moore,','Misty Blue'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk Two - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,3,'Jackson Southernaires','Travel On'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk Two - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,1,'Freedom','Dance, Sing Along'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk Three - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,2,'Fern Kinney','Groove Me'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk Three - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,3,'Freedom','Get and Dance'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk Three - The Last Soul Company'
GO

INSERT INTO CD_Tracks (cd_id,track_number,artist_name,track_title)
SELECT cd_id,4,'Fern Kinney','Together We Are Beautiful'
FROM   CDs
      ,CD_Sets
WHERE  cd_sets.cd_set_name = 'The Last Soul Company'
AND    CD_Title = 'Disk Three - The Last Soul Company'
GO






INSERT INTO CD_Tracks (cd_id,track_number,track_title) 
SELECT cd_id, 1,'Don"t Know Why'
FROM   CDs
WHERE  CD_title = 'come away with me';
GO

INSERT INTO CD_Tracks (cd_id,track_number,track_title) 
SELECT cd_id, 2,'Seven Years'
FROM   CDs
WHERE  CD_title = 'come away with me';
GO

INSERT INTO CD_Tracks (cd_id,track_number,track_title) 
SELECT cd_id, 3,'Cold, Cold Heart'
FROM   CDs
WHERE  CD_title = 'come away with me';
GO

INSERT INTO CD_Tracks (cd_id,track_number,track_title) 
SELECT cd_id, 4,'Come Away With Me'
FROM   CDs
WHERE  CD_title = 'come away with me';
GO

/* ---------------------------------------------------------------------- */
/* Add table "Artists_on_Tracks"                                          */
/* ---------------------------------------------------------------------- */

CREATE TABLE [Artists_on_Tracks] (
    [cd_id] UNIQUEIDENTIFIER,
    [track_number] INTEGER,
    [artist_name] VARCHAR(80),
PRIMARY KEY (cd_id,track_number,artist_name),
FOREIGN KEY (cd_id) REFERENCES CDs (cd_id),
FOREIGN KEY (artist_name) REFERENCES ARTISTs (artist_name)
)
GO

CREATE VIEW Artists_on_CDs AS 
(SELECT DISTINCT CD_Title,CDS.artist_name
FROM Artists_on_Tracks AOT
    ,CDs
WHERE AOT.cd_id = CDs.cd_id);
GO

INSERT INTO Artists_on_Tracks (cd_id,track_number,artist_name) 
SELECT cds.cd_id,track_number,'Norah Jones' as artist_name
FROM   cds
      ,cd_tracks
WHERE  cds.cd_id = cd_tracks.cd_id
AND    cd_title = 'come away with me';
GO



/* Diagnostics */

SELECT 'Tracks in CD Sets' As Table_Name,cd_sets.cd_set_name,cd_title,track_number,cd_tracks.artist_name,track_title
FROM   CDs
      ,CD_Sets
      ,CD_Tracks
WHERE  cd_sets.cd_set_id = cds.cd_set_id
AND    cds.cd_id = CD_Tracks.cd_id
ORDER  BY cd_sets.cd_set_name,cd_title,track_number
GO

SELECT  'Artists_on_Tracks' As Table_name, cd_id,track_number,artist_name
FROM Artists_on_Tracks;
GO

SELECT 'Artists_on_CDs' As View_name,CD_Title,artist_name
FROM   Artists_on_CDs
ORDER BY cd_title,artist_name;
GO

