/* ------------------------------------------------------------------------------------ */
/* Filename    : drop_cd_collections_tables.sql                                        	*/
/* Usage       : This SQL Script should be run after the cre_cd_collections_tables.sql 	*/
/* Project name: 10 Data Models for SQL Server 2005 Express Edition                    	*/
/* Author      : Barry Williams                                                 	*/
/* Created at  : 10.00 am on Saturday, 26th. August 2006                  		*/
/* ------------------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------------------ */
/* Drop Tables and Views                                                  		*/
/* ------------------------------------------------------------------------------------ */

DROP VIEW Artists_on_CDs 
GO

DROP TABLE Artists_on_Tracks 
GO

DROP TABLE CD_Tracks 
GO

DROP TABLE CDs
GO

DROP TABLE CD_Sets
GO

DROP TABLE Artists
GO

DROP TABLE Record_Companies 
GO

DROP TABLE Ref_CD_Outlets
GO

DROP TABLE Ref_Music_Genres
GO


   

